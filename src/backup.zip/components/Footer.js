import React from "react";
import PropTypes from "prop-types";
import Link from "./Link";

const Footer = () => (
  <div>
    <span>Show:</span>
    <Link>All</Link>
    <Link>Active</Link>
    <Link>Completed</Link>
  </div>
);

Footer.propTypes = {};

export default Footer;
