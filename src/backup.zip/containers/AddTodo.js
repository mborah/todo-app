import React from "react";

const AddTodo = () => {
  return (
    <div>
      <form
        onSubmit={e => {
          e.preventDefault();
        }}
      >
        <input type="text" />
        <button>Add Todo</button>
      </form>
      <br />
      <br />
    </div>
  );
};

AddTodo.propTypes = {};

export default AddTodo;
