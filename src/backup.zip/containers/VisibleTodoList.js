import React from "react";
import PropTypes from "prop-types";

function VisibleTodoList(props) {
  return <div />;
}

VisibleTodoList.propTypes = {};

export default VisibleTodoList;
